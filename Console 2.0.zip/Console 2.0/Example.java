public class Example {
	public static void main(String[] args) {
		Application app = new Application();
		app.write("Example program.");
		app.writeln("Please enter any int: ");
		int a = 0;
		a = app.get(a);
		app.writeln("You chose: " + a);
		app.writeln("Don't miss menu on top.");
	}
}